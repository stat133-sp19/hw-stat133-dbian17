## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(Binomial)

## ------------------------------------------------------------------------
var <- bin_variable(20, .6)
var
var$trials
var$prob

## ------------------------------------------------------------------------

summary(var)


## ------------------------------------------------------------------------

bin_probability(2, 5, .4)

## ------------------------------------------------------------------------
bin_mean(10, .2)
bin_variance(10, .2)
bin_mode(10, .2)
bin_skewness(10, .2)
bin_kurtosis(10, .2)


## ------------------------------------------------------------------------
pdf_var <- bin_distribution(var$trials, var$prob)
pdf_var

cdf_var <- bin_cumulative(var$trials, var$prob)
cdf_var


## ------------------------------------------------------------------------
plot(pdf_var)
plot(cdf_var)

