library(testthat)
library(binomial)