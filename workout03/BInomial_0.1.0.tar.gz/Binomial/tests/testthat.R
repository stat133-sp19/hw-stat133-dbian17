library(testthat)
library(Binomial)

test_check("Binomial")